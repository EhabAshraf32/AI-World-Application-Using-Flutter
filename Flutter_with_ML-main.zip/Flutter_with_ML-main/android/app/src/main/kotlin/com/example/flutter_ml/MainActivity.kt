package com.example.flutter_ml

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
